// Define service dependencies here
return [
    "serviceregistry": ["config-server"],
    "membership-service": ["serviceregistry", "config-server"],
    "identity-service": ["serviceregistry", "config-server"],
    "api-gateway": ["serviceregistry", "config-server"],
    "admin-server": ["serviceregistry", "config-server"],
    "wps-service": ["serviceregistry", "config-server"],
    "transaction-management": ["serviceregistry", "config-server"],
    "card-payment-service": ["serviceregistry", "config-server"]
]
