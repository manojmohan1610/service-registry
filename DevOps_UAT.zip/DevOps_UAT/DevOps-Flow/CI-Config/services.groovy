// Define all microservices metadata here
return [
    [name: "config-server", path: "configserver", image_name: "configserver", artifact: "configserver-0.0.1-SNAPSHOT", port: 8181],
    [name: "serviceregistry", path: "serviceregistry", image_name: "serviceregistry", artifact: "serviceregistry-0.0.1-SNAPSHOT", port: 8761],
    [name: "membership-service", path: "membershipservice/membershipservice-executor", image_name: "membershipservice-executor", artifact: "membershipservice-executor-0.0.1-SNAPSHOT", port: 8086],
    [name: "identity-service", path: "identityservice", image_name: "identityservice", artifact: "identityservice-0.0.1-SNAPSHOT", port: 8090],
    [name: "api-gateway", path: "api-gateway", image_name: "api-gateway", artifact: "api-gateway-0.0.1-SNAPSHOT", port: 8083],
    [name: "admin-server", path: "springboot-admin-server", image_name: "springboot-admin-server", artifact: "springboot-admin-server-1.0-SNAPSHOT", port: 8092],
    [name: "wps-service", path: "wps-service", image_name: "wps-service", artifact: "wps-service-0.0.1-SNAPSHOT", port: 8087],
    [name: "transaction-management", path: "transaction-management", image_name: "transaction-management", artifact: "transaction-management-0.0.1-SNAPSHOT", port: 8089],
    [name: "card-payment-service", path: "card-payment-service", image_name: "card-payment-service", artifact: "card-payment-service-0.0.1-SNAPSHOT", port: 8094]
]
