#!/bin/bash

# 1. Create network
docker network create jfrog-net

# 2. Create storage
mkdir -p /data/jfrog/artifactory/var
chown -R 1030:1030 /data/jfrog/artifactory/var

# 3. Start PostgreSQL
docker run -d \
  --name jfrog-postgres \
  --network jfrog-net \
  -e POSTGRES_DB=artifactorydb \
  -e POSTGRES_USER=artifactory \
  -e POSTGRES_PASSWORD='jcrpassword' \
  -v /data/jfrog/postgres:/var/lib/postgresql/data \
  postgres:14

# 4. Start JFrog Artifactory JCR
docker run -d \
  --name jfrog-artifactory-jcr \
  --network jfrog-net \
  -p 8081:8081 \
  -p 8082:8082 \
  -v /data/jfrog/artifactory/var/:/var/opt/jfrog/artifactory \
  --restart unless-stopped \
  releases-docker.jfrog.io/jfrog/artifactory-jcr:7.133.8
