
# JFrog Container Registry (JCR) – UAT Setup Guide

This document explains how to set up **JFrog Artifactory – Container Registry (JCR)** in the **UAT environment (offline)** using the files available in this directory.

You can install JCR using **either**:
- Shell script (`jcr-setup.sh`)
- Docker Compose (`docker-compose.yaml`)

---

## Prerequisites (Mandatory)

### 1. Docker Installed and Running

```bash
docker --version
sudo systemctl status docker
```

### 2. Required Directories
Create persistent storage directories:
```bash
sudo mkdir -p /data/jfrog/artifactory/var
sudo mkdir -p /data/jfrog/postgres
sudo chown -R 1030:1030 /data/jfrog/artifactory/var
```
UID 1030 is required for the Artifactory container user.

## Method 1: JCR Setup Using Shell Script

### Steps

```bash
1. Navigate to JCR directory:
cd DevOps/scripts/JCR

2. Update database password inside the script:
sudo vi jcr-setup.sh

3. Replace:
POSTGRES_PASSWORD=jcrpassword

4. Make the script executable:
sudo chmod +x jcr-setup.sh

5. Execute the script:
./jcr-setup.sh
```
---
## Method 2: JCR Setup Using Docker Compose

### Steps

```bash
1. Navigate to JCR directory:
cd DevOps/scripts/JCR

2. Edit the compose file and update database password:
sudo vi docker-compose.yaml

3. Replace:
POSTGRES_PASSWORD: jcrpassword

4. Start JCR using Docker Compose:
docker compose up -d

5. Verify running containers:
docker compose ps
```

## Post‑Installation Verification
```bash
1. Check Artifactory Logs
docker logs jfrog-artifactory-jcr --tail=50

2. Access JCR UI: Open browser
http://<SERVER_IP>:8081/

3. Health Check
curl http://localhost:8081/artifactory/api/system/ping

Expected output: OK
```
