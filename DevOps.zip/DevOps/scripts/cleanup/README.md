# UAT Log Cleanup — `archive-messages.sh` (Cron)

## Overview
In the UAT environment (nodes `172.18.250.180` and `172.18.250.181`), we run a daily cron job to **archive rotated system message logs** from `/var/log` to a dedicated archive location under `/var/log/kubernetes/host-logs/messages/`.

This cleanup prevents `/var/log` from growing indefinitely while still retaining historical logs for troubleshooting and audit purposes.

---

## What This Job Archives
The script targets **rotated** message files matching this pattern:

- `messages-[0-9]*`  
  Example:
  - `messages-20260125`
  - `messages-20260126`
  - (after compression) `messages-20260125.gz`

> Note: The active `/var/log/messages` file is **not** touched.

---

## Script Location
- Script path:
  - `/usr/local/sbin/archive-messages.sh`

- Script log:
  - `/var/log/kubernetes/archive-messages.log`

- Cron stdout/stderr capture:
  - `/var/log/kubernetes/archive-messages.cron.out`

- Lock file (prevents concurrent runs):
  - `/var/lock/archive-messages.lock`

---

## Destination (Archive) Location
Archives are stored under a year/month directory structure:

- Base directory:
  - `/var/log/kubernetes/host-logs/messages/`

- Final destination directory (auto-created):
  - `/var/log/kubernetes/host-logs/messages/<YYYY>/<MM>/`

Example:
- `/var/log/kubernetes/host-logs/messages/2026/02/`

The script enforces:
- `chmod 750` on the destination directory
- `chown root:root` on the destination directory

---

## Retention Policy
Default retention is set to **30 days**:

- Files older than 30 days are deleted from the archive base:
  - `*.gz`
  - `SHA256SUMS-*.txt`

To change retention, edit in the script:
- `RETENTION_DAYS="30"`

---

## Integrity Manifest (SHA256)
After moving compressed logs, the script writes a checksum manifest inside the monthly archive folder:

- Manifest name format:
  - `SHA256SUMS-YYYY-MM-DD.txt`

Example:
- `SHA256SUMS-2026-02-02.txt`

This helps verify that archived `.gz` files were not corrupted or modified.

---

## Cron Schedule
Cron is configured here:

- `/etc/cron.d/archive-messages`

Current schedule: **daily at 03:00 AM** (runs as root)

## How It Works (High Level)
1. Acquires an exclusive lock using `/var/lock/archive-messages.lock`  
   - If another instance is running, it exits safely.
2. Creates destination folder based on current year and month.
3. Finds rotated message files in `/var/log` matching `messages-[0-9]*`.
4. Compresses files (if not already compressed) using `gzip -9`.
5. Moves compressed files into the destination folder (non-overwriting move).
6. Generates a SHA256 checksum manifest for the `.gz` files.
7. Deletes archived files and manifests older than the retention period.

---

## Requirements / Dependencies
This script expects common utilities available on RHEL:
- `bash`
- `find`
- `gzip`
- `sha256sum`
- `flock` (typically from `util-linux`)

---

## Manual Run (For Testing)
Run as root (or via sudo): sudo /usr/local/sbin/archive-messages.sh

---

## Verification Checklist
After a run, confirm:

1. Cron output exists/updated:
   - `/var/log/kubernetes/archive-messages.cron.out`

2. Script log contains successful completion:
   - `/var/log/kubernetes/archive-messages.log`

3. Archived files present:
   - `/var/log/kubernetes/host-logs/messages/<YYYY>/<MM>/messages-*.gz`

4. Manifest created:
   - `/var/log/kubernetes/host-logs/messages/<YYYY>/<MM>/SHA256SUMS-YYYY-MM-DD.txt`

Optional: Validate checksums inside the archive folder: cd /var/log/kubernetes/host-logs/messages///
sha256sum -c SHA256SUMS-YYYY-MM-DD.txt

---

## Troubleshooting
### No files archived
- The script only processes rotated files matching:
  - `messages-[0-9]*`
- If logrotate naming differs, update `PATTERN` in the script.

### “Another instance is running”
- Lock file prevents concurrent runs.
- Check for a stuck process:
  - Look for a running `archive-messages.sh` process.
- If safe, remove the lock file:
  - `/var/lock/archive-messages.lock`

### Permission or path errors
- Ensure `/var/log/kubernetes/` exists and is writable by root.
- Ensure destination base exists or can be created.

---

## Rollback / Disable
To stop the scheduled job:
- Comment out or remove the cron line in:
  - `/etc/cron.d/archive-messages`

To remove the script:
- Remove `/usr/local/sbin/archive-messages.sh` (only after disabling cron)

---

## Files Included in This Setup
- `/usr/local/sbin/archive-messages.sh`
- `/etc/cron.d/archive-messages`
