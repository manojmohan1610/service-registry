# Delete un-used digitalwallet local docker images

#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="aadp-micro-apps"
IMAGE_FILTER="digitalwallet"

echo "========================================="
echo "[INFO] Collecting Kubernetes-used images"
echo "========================================="

USED_IMAGES=$(kubectl -n "$NAMESPACE" get pods \
  -o jsonpath='{range .items[*]}{range .spec.containers[*]}{.image}{"\n"}{end}{end}' \
  | grep "$IMAGE_FILTER" \
  | sort -u)

echo "[INFO] Images currently in use:"
echo "$USED_IMAGES"

echo "========================================="
echo "[INFO] Collecting LOCAL Docker images"
echo "========================================="

LOCAL_IMAGES=$(docker images --format '{{.Repository}}:{{.Tag}}' \
  | grep "$IMAGE_FILTER" \
  | sort -u)

echo "[INFO] Local $IMAGE_FILTER images:"
echo "$LOCAL_IMAGES"

echo "========================================="
echo "[INFO] Identifying UNUSED images"
echo "========================================="

UNUSED_IMAGES=()

while IFS= read -r img; do
    [[ "$img" == *"<none>"* ]] && continue
    if ! grep -qx "$img" <<< "$USED_IMAGES"; then
        UNUSED_IMAGES+=("$img")
    fi
done <<< "$LOCAL_IMAGES"

if [[ "${#UNUSED_IMAGES[@]}" -eq 0 ]]; then
    echo "[INFO] No unused digitalwallet images found"
    exit 0
fi

echo "[INFO] digitalwallet images eligible for removal:"
for img in "${UNUSED_IMAGES[@]}"; do
    echo " - $img"
done

echo "========================================="
echo "[INFO] Removing unused images"
echo "========================================="

for img in "${UNUSED_IMAGES[@]}"; do
    echo "[INFO] Removing $img"
    docker rmi -f "$img" || echo "[WARN] Failed to remove $img"
done

echo "========================================="
echo "[SUCCESS] digitalwallet image cleanup complete"
docker images | grep "$IMAGE_FILTER" || true
