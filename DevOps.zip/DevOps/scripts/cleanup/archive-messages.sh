#!/usr/bin/env bash
set -euo pipefail

# ---- Config ----
SRC_DIR="/var/log"
DEST_BASE="/var/log/kubernetes/host-logs/messages"
RETENTION_DAYS="30"   # change as needed (e.g., 90)
LOG_FILE="/var/log/kubernetes/archive-messages.log"
LOCK_FILE="/var/lock/archive-messages.lock"

# Only rotated messages files (example: messages-20260125)
PATTERN='messages-[0-9]*'

# ---- Functions ----
log() { echo "[$(date -Is)] $*" | tee -a "$LOG_FILE" ; }

# ---- Lock (avoid concurrent runs) ----
exec 9>"$LOCK_FILE"
if ! flock -n 9; then
  log "Another instance is running. Exiting."
  exit 0
fi

# ---- Prepare destination ----
YEAR="$(date +%Y)"
MONTH="$(date +%m)"
DEST_DIR="${DEST_BASE}/${YEAR}/${MONTH}"
mkdir -p "$DEST_DIR"
chmod 750 "$DEST_DIR"
chown root:root "$DEST_DIR"

log "Starting archive job. Source=$SRC_DIR Dest=$DEST_DIR"

# ---- Find rotated files and process ----
mapfile -t files < <(find "$SRC_DIR" -maxdepth 1 -type f -name "$PATTERN" -print)

if [[ "${#files[@]}" -eq 0 ]]; then
  log "No rotated messages files found. Nothing to do."
else
  for f in "${files[@]}"; do
    # Skip if file disappeared between find and loop
    [[ -f "$f" ]] || continue

    # Compress if not already compressed
    if [[ "$f" != *.gz ]]; then
      log "Compressing: $f"
      gzip -9 "$f"
      f="${f}.gz"
    fi

    # Move to destination; keep filename
    base="$(basename "$f")"
    log "Moving: $f -> $DEST_DIR/$base"
    mv -n "$f" "$DEST_DIR/$base"
  done
fi

# ---- Optional: integrity manifest (good practice) ----
MANIFEST="${DEST_DIR}/SHA256SUMS-$(date +%F).txt"
log "Writing manifest: $MANIFEST"
( cd "$DEST_DIR" && sha256sum *.gz 2>/dev/null || true ) > "$MANIFEST" || true

# ---- Retention cleanup ----
log "Applying retention: delete archives older than ${RETENTION_DAYS} days"
find "$DEST_BASE" -type f -mtime +"$RETENTION_DAYS" -name "*.gz" -delete || true
find "$DEST_BASE" -type f -mtime +"$RETENTION_DAYS" -name "SHA256SUMS-*.txt" -delete || true

log "Archive job completed."
