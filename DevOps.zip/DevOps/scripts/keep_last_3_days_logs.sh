#!/bin/bash
# Script to keep only last 3 days logs in /home/oracle/digitalwallet/logs and remove old archived logs
# NOTE: It will remove all the log content and files older than 3 days
# Execute only in TEST Servers not in UAT or PRODUCTION Servers 

LOG_DIR="/home/oracle/digitalwallet/logs"
DAYS=3

# Calculate last 3 days in both formats YYYY-MM-DD and YYYY/MM/DD
DATES=""
for i in $(seq 0 $((DAYS-1))); do
    DATES="$DATES$(date -d "-$i day" '+%Y-%m-%d')|$(date -d "-$i day" '+%Y/%m/%d')|"
done
DATES="${DATES%|}"

echo "Filtering logs for dates: $DATES"

# Process main .log files (truncate to last 3 days)
find "$LOG_DIR" -type f -name "*.log" ! -path "*/archived/*" | while read -r LOGFILE; do
    echo "Processing main log: $LOGFILE"
    TEMP="${LOGFILE}.tmp"
    sudo sh -c "grep -E \"$DATES\" \"$LOGFILE\" > \"$TEMP\""
    sudo mv "$TEMP" "$LOGFILE"
done

# Remove old archived logs (keep only last 3 days)
echo "Cleaning archived logs..."
find "$LOG_DIR" -type f -path "*/archived/*" -name "*.log" | while read -r ARCHIVEFILE; do
    # Extract date from filename (assuming format: name-YYYY-MM-DD.something.log)
    FILEDATE=$(echo "$ARCHIVEFILE" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}')
    if [[ -n "$FILEDATE" ]]; then
        # Check if file is older than 3 days
        if [[ $(date -d "$FILEDATE" +%s) -lt $(date -d "-$DAYS days" +%s) ]]; then
            echo "Removing old archive: $ARCHIVEFILE"
            sudo rm -f "$ARCHIVEFILE"
        fi
    fi
done

echo "Log cleanup completed."
