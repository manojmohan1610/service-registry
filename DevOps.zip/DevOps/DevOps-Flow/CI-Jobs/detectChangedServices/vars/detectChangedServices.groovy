#!/usr/bin/env groovy

def call(Map config = [:]) {
    def repoPath = config.repoPath ?: "AADP-MICRO-APPS/digitalwallet"
    def modules = config.modules ?: []

    withCredentials([usernamePassword(credentialsId: 'github-AADP', usernameVariable: 'GIT_USER', passwordVariable: 'GIT_TOKEN')]) {
        // Configure Git to use the credentials
        sh """
            git config --global credential.helper store
            git config --global user.name "${GIT_USER}"
            git config --global user.password "${GIT_TOKEN}"
            git fetch https://${GIT_USER}:${GIT_TOKEN}@github.com/github-AADP/DevOps.git main
        """

        // Get changed files compared to main branch
        def changedFiles = sh(
            script: "git diff --name-only origin/main...HEAD",
            returnStdout: true
        ).trim().split("\n")

        echo "Changed files compared to main: ${changedFiles}"

        def changedServices = []
        modules.each { svc ->
            if (changedFiles.any { it.startsWith("${repoPath}/${svc.path}") }) {
                changedServices << svc
            }
        }

        if (changedServices.isEmpty()) {
            echo "No matching services detected"
            return
        }

        echo "Changed services detected: ${changedServices*.name}"
        return changedServices
    }
}
