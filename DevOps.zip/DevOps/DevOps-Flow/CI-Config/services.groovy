// Define all microservices metadata here
return [
        [name: "config-server", path: "configserver", image_name: "configserver", artifact: "configserver-0.0.1-SNAPSHOT", port: 8181],
        [name: "serviceregistry", path: "serviceregistry", image_name: "serviceregistry", artifact: "serviceregistry-0.0.1-SNAPSHOT", port: 8761],
        [name: "membership-service", path: "membershipservice/membershipservice-executor", image_name: "membershipservice-executor", artifact: "membershipservice-executor-0.0.1-SNAPSHOT", port: 8086],
        [name: "identity-service", path: "identityservice", image_name: "identityservice", artifact: "identityservice-0.0.1-SNAPSHOT", port: 8090],
        [name: "api-gateway", path: "api-gateway", image_name: "api-gateway", artifact: "api-gateway-0.0.1-SNAPSHOT", port: 8083],
        [name: "admin-server", path: "springboot-admin-server", image_name: "springboot-admin-server", artifact: "springboot-admin-server-1.0-SNAPSHOT", port: 8092],
        [name: "wps-service", path: "wps-service", image_name: "wps-service", artifact: "wps-service-0.0.1-SNAPSHOT", port: 8087],
        [name: "transaction-management", path: "transaction-management", image_name: "transaction-management", artifact: "transaction-management-0.0.1-SNAPSHOT", port: 8089],
        [name: "card-payment-service", path: "card-payment-service", image_name: "card-payment-service", artifact: "card-payment-service-0.0.1-SNAPSHOT", port: 8094],
        [name: "ewa-service", path: "ewa-service", image_name: "ewa-service", artifact: "ewa-service-0.0.1-SNAPSHOT", port: 8096],
        [name: "notification-service", path: "notification-service", image_name: "notification-service", artifact: "notification-service-0.0.1-SNAPSHOT", port: 8097],
        [name: "promotion-service", path: "promotion-service", image_name: "promotion-service", artifact: "promotion-service-0.0.1-SNAPSHOT", port: 8098],
        [name: "kiosk-service", path: "kiosk-service", image_name: "kiosk-service", artifact: "kiosk-service-0.0.1-SNAPSHOT", port: 8095],
        [name: "fee-management-service", path: "fee-management-service", image_name: "fee-management-service", artifact: "fee-management-service-0.0.1-SNAPSHOT", port: 8099],
        [name: "universal-account-service", path: "universal-account-service", image_name: "universal-account-service", artifact: "universal-account-service-0.0.1-SNAPSHOT", port: 8084],       
        [name: "card-management-service", path: "card-management-service", image_name: "card-management-service", artifact: "card-management-service-0.0.1-SNAPSHOT", port: 8085],
        [name: "viban-service", path: "viban-service", image_name: "viban-service", artifact: "viban-service-0.0.1-SNAPSHOT", port: 8093]
]
