// Define service dependencies here
return [
        "serviceregistry": ["config-server"],
        "membership-service": ["serviceregistry", "config-server"],
        "identity-service": ["serviceregistry", "config-server"],
        "api-gateway": ["serviceregistry", "config-server"],
        "admin-server": ["serviceregistry", "config-server"],
        "wps-service": ["serviceregistry", "config-server"],
        "transaction-management": ["serviceregistry", "config-server"],
        "card-payment-service": ["serviceregistry", "config-server"],
        "ewa-service": ["serviceregistry", "config-server"],
        "notification-service": ["serviceregistry", "config-server"],
        "promotion-service": ["serviceregistry", "config-server"],
        "kiosk-service": ["serviceregistry", "config-server"],
        "fee-management-service": ["serviceregistry", "config-server"],
        "universal-account-service": ["serviceregistry", "config-server"],        
        "card-management-service": ["serviceregistry", "config-server"],
        "viban-service": ["serviceregistry", "config-server"]
]
