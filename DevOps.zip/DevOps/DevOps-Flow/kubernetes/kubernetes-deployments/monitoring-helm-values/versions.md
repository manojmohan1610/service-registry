# Versions used for monitoring components and envoy gateway

| Component | Helm Chart | App Version |
|---------|-----------|-------------|
| Alloy | 1.5.1 | v1.12.1 |
| Loki | 6.49.0 | 3.6.3 |
| Tempo | 1.24.1 | 2.9.0 |
| Prometheus | 80.9.1 | 0.87.1 |
| Envoy Gateway | v1.6.1 | v1.6.1 |
