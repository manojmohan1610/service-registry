# Kubernetes Cluster Setup Guide (UAT 172.18.250.180 and 181)

## Overview
This document provides a complete end-to-end guide to setting up Kubernetes clusters for different
environments — TEST, UAT, and PRODUCTION — optimized for running microservice-based Java Spring
applications. It includes detailed dependency lists, configuration steps, system recommendations, and
architecture diagrams for high availability (HA) setups.

## Dependencies and System Requirements
* Operating System: RHEL - > 9.5

## Hardware Requirements

| Environment | Control Plane Nodes | Worker Nodes | vCPU | RAM | Storage |
|-------------|---------------------|--------------|------|-----|---------|
| TEST | 1 | 0 | 8 | 16 GB | 100 GB |
| UAT | 1 | 1 | 8 | 16 GB | 100 GB |
| PROD | 3 | 6+ | 8+ | 32 GB+ | 100 GB+ |

## Required Firewall Ports (All Nodes)

| Port | Protocol | Purpose |
|-----|---------|--------|
| 6443 | TCP | Kubernetes API Server |
| 2379-2380 | TCP | etcd |
| 10250 | TCP | kubelet API |
| 8472 | UDP | Flannel VXLAN |
| 30000-32767 | TCP | NodePort Services |

## Version Lock Summary

| Component | Version |
|---------|---------|
| Kubernetes | v1.33.x |
| CNI | Flannel v0.25.5 |
| Runtime | Docker + cri-dockerd |
| Helm | v3.19.0 |

---
## Step 1 – System Preparation (All Nodes)
### Install Required Packages
```bash
sudo dnf install -y yum-utils device-mapper-persistent-data lvm2
sudo dnf install -y curl wget vim git tar
```
### Load Kernel Modules
```bash
cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF

sudo modprobe overlay
sudo modprobe br_netfilter
```

### Configure sysctl Parameters
```bash
cat <<EOF | sudo tee /etc/sysctl.d/99-kubernetes-cri.conf
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                = 1
EOF

sudo sysctl --system
```

### Disable Swap
```bash
sudo swapoff -a
sudo sed -i '/ swap / s/^/#/' /etc/fstab
```

### Configure SELinux
```bash
sudo setenforce 0
sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config
```
---
## Step 2 – Install cri‑dockerd

### Install Go (Go 1.24.x)
```bash
remove old go version if installed
sudo dnf remove golang -y

cd /tmp
curl -OL https://go.dev/dl/go1.24.9.linux-amd64.tar.gz
sudo rm -rf /usr/local/go
sudo tar -C /usr/local -xzf go1.24.9.linux-amd64.tar.gz

echo 'export PATH=$PATH:/usr/local/go/bin' | sudo tee /etc/profile.d/go.sh
source /etc/profile.d/go.sh
go version
```
### Build and Install cri‑dockerd
```bash
git clone https://github.com/Mirantis/cri-dockerd.git
cd cri-dockerd
go clean -modcache
go build -o bin/cri-dockerd

sudo install -o root -g root -m 0755 bin/cri-dockerd /usr/local/bin/cri-dockerd
```

### Configure and Enable cri‑dockerd Service
```bash
sudo cp packaging/systemd/* /etc/systemd/system/
sudo sed -i 's,/usr/bin/cri-dockerd,/usr/local/bin/cri-dockerd,g' \
  /etc/systemd/system/cri-docker.service

sudo systemctl daemon-reload
sudo systemctl enable --now cri-docker.service
sudo systemctl enable --now cri-docker.socket
```

### Verify cri Socket
```bash
ls -l /run/cri-dockerd.sock
```
---
## Step 3 – Install Kubernetes Components (v1.33.6 - Locked)

### Add Kubernetes Repository
```bash

sudo tee /etc/yum.repos.d/kubernetes.repo <<EOF
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.33/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.33/rpm/repodata/repomd.xml.key
EOF
```
### Install kubeadm, kubelet, kubectl
```bash

sudo dnf install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
sudo systemctl enable --now kubelet
sudo systemctl restart --now kubelet

sudo systemctl status kubelet
sudo systemctl status docker

NOTE: The above 2 services docker and kubelet should be up and running
```
---
## Step 4 – Initialize Cluster (TEST Single Node / UAT Multi node)
```bash
sudo kubeadm init \
  --kubernetes-version=v1.33.6 \
  --pod-network-cidr=10.244.0.0/16 \
  --cri-socket=unix:///run/cri-dockerd.sock
```
**NOTE: Copy kubeadm join command to add worker nodes to cluster*

### Configure kubectl for current user
```bash
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
```

### Apply Network Add-on
```bash
kubectl apply -f https://github.com/flannel-io/flannel/releases/download/v0.25.5/kube-flannel.yml
```

### Allow scheduling pods on control-plane
```bash
kubectl taint nodes --all node-role.kubernetes.io/control-plane-
```
---
## Step 5 – Verify the installation 
```bash
kubectl get nodes
kubectl get pods -A
kubectl get pods -n kube-system -A 
```
---
## Step 6 - Important command to add new node to this cluster for future reference: 
```bash
kubeadm join 172.18.250.180:6443 --token 0l1r7m.i09deowwnafn6wkx \
    --discovery-token-ca-cert-hash sha256:107b9d17c031119a461c23fdcda4fc2d11204dfb50c1fc0c969e2e8254fcebdd \
    --cri-socket=unix:///run/cri-dockerd.sock

to generate above command in case of lost

kubeadm token create --print-join-command

Check existing tokens
kubeadm token list

Create a token valid for 24h:
kubeadm token create

Create token with extended expiry (example: 48h):
kubeadm token create --ttl 48h

Delete a token:
kubeadm token delete <token-id>

NOTE: Execute kubeadm init command in control-plane and kubeadm join command in worker nodes to join as a worker into cluster
```

---
## Important Notes

- `cri-dockerd` must run on **all nodes**
- Always pass `--cri-socket` for init and join
- `pod-network-cidr=10.244.0.0/16` is **mandatory for Flannel**
- Keep versions **locked across environments**
- Archive RPMs & images for air‑gapped PROD clusters

**This README alone is sufficient for future k8s setup in any environments exactly like UAT**

# Helm installation steps

### Download Helm v3.19.0 (Linux x86_64)
```bash
curl -LO https://get.helm.sh/helm-v3.19.0-linux-amd64.tar.gz
tar -zxvf helm-v3.19.0-linux-amd64.tar.gz
sudo mv linux-amd64/helm /usr/local/bin/helm

helm version
Expected output will be: version.BuildInfo{Version:"v3.19.0", GitCommit:"...", GitTreeState:"clean", GoVersion:"go1.24.*"}
NOTE: Helm is installed on CI / Admin nodes, not inside Kubernetes.
```
---
### Post‑Install kubernetes cluster Health Checks | Final Validation of kubernetes setup:
```bash
kubectl version
kubectl get ns
kubectl cluster-info
kubectl get nodes -o wide
kubectl get pods -n kube-system
helm version
```
![Kubernetes-UAT-setup-verification](Images/kubernetes-UAT-setup-verification.png)

---
# Kubernetes Observability Stack – UAT & Production Reference

## Overview
This repository documents the complete observability stack deployed on Kubernetes
using Helm. The setup is validated in the UAT environment and serves as a reference
for Production deployment.

## Mandatory Installation Order

1. Prometheus (kube-prometheus-stack)
2. Loki
3. Tempo
4. Alloy
5. Envoy Gateway

### Reason:
Alloy forwards telemetry to Prometheus, Loki, and Tempo.
Backends must be available before Alloy starts.

## Components Deployed

| Component | Purpose | Helm Chart | App Version |
|---------|--------|-----------|------------|
| Alloy | Metrics & Logs Agent | alloy-1.5.1 | v1.12.1 |
| Prometheus | Metrics Monitoring | kube-prometheus-stack-80.9.1 | v0.87.1 |
| Loki | Log Aggregation | loki-6.49.0 | 3.6.3 |
| Tempo | Distributed Tracing | tempo-1.24.1 | 2.9.0 |
| Envoy Gateway | Ingress & Traffic | gateway-helm-v1.6.1 | v1.6.1 |

## Namespaces Used

- monitoring
- envoy-gateway-system

## Minimum Helm Version
```bash
Helm v3.19.0
```

# Kubernetes Observability Stack – UAT → Production Reference

**Environment context**
- Helm version: v3.19.0
- UAT namespaces: `monitoring`, `envoy-gateway-system`
- UAT releases: `prometheus`, `loki`, `tempo`, `alloy` (observability); `eg` (Envoy Gateway)

> This repository documents the observability stack validated in UAT and provides a repeatable, production-ready installation path, including values files, prerequisites, installation order, and air‑gapped procedures.


## Components

| Component | Purpose | Helm Chart | Release | Namespace |
|----------|---------|------------|---------|-----------|
| Prometheus Stack | Metrics, Alerting, Grafana | `prometheus-community/kube-prometheus-stack` | `prometheus` | `monitoring` |
| Loki | Log aggregation | `grafana/loki` | `loki` | `monitoring` |
| Tempo | Distributed tracing | `grafana/tempo` | `tempo` | `monitoring` |
| Alloy | Unified agent for metrics/logs/traces | `grafana/alloy` | `alloy` | `monitoring` |
| Envoy Gateway | Ingress/Gateway management | `envoyproxy/gateway-helm` | `eg` | `envoy-gateway-system` |

> **Install order (MANDATORY)**: 1) Prometheus → 2) Loki → 3) Tempo → 4) Alloy → *(Envoy Gateway separately)*  
> Reason: Alloy emits to Prometheus/Loki/Tempo; backends must be ready first.

# Prometheus – kube‑prometheus‑stack (UAT)
## Purpose
Provides Cluster‑wide metrics collection, alerting, and Grafana dashboards.

Chart version used in UAT:

* Chart: kube-prometheus-stack
* Version: 80.9.1
* App version: Prometheus Operator v0.87.1
* Namespace: monitoring
* Release: prometheus

## Install Commands
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm upgrade --install prometheus prometheus-community/kube-prometheus-stack \
  --version 80.9.1 \
  -n monitoring \
  -f monitoring-helm-values/prometheus-values.yaml \
  --create-namespace
```

## Validation
```bash
kubectl get pods -n monitoring
```
### Expected pods:
* prometheus-kube-prometheus-prometheus-*
* alertmanager-kube-prometheus-alertmanager-*
* prometheus-grafana-*
* kube-state-metrics-*
* node-exporter-*

## Rollback
```bash
helm history prometheus -n monitoring
helm rollback prometheus <revision> -n monitoring
```

## Important Notes
* Prometheus & Alertmanager are managed by Prometheus Operator
* Always use Helm for upgrades and rollbacks
* Avoid manual changes to CRDs created by the chart
* Review retention, PVC size, and resource limits for PROD
* Secure Grafana access (Ingress + TLS recommended)

# Loki – Log Aggregation System

## Purpose
Loki provides centralized **log aggregation** for Kubernetes workloads and
integrates with Grafana for log querying and visualization.

Chart version used in UAT:

* Chart: loki
* Version: 6.49.0
* App version: 3.6.3
* Namespace: monitoring
* Release: loki

## Install Commands
```bash
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

helm upgrade --install loki grafana/loki \
  --version 6.49.0 \
  -n monitoring \
  -f monitoring-helm-values/loki-values.yaml \
  --create-namespace
```

## Validation
```bash
kubectl get pods -n monitoring
kubectl logs -n monitoring statefulset/loki
```

## Rollback
```bash
helm rollback loki <revision> -n monitoring
```

## Notes
* Requires persistent storage (PVC)

# Tempo – Distributed Tracing Backend

## Purpose
* Tempo stores and queries **distributed traces** received from applications and observability agents like Alloy.

Chart version used in UAT:

* Chart: tempo
* Version: 1.24.1
* App version: 2.9.0
* Namespace: monitoring
* Release: tempo

## Install Commands
```bash
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

helm upgrade --install tempo grafana/tempo \
  --version 1.24.1 \
  -n monitoring \
  -f monitoring-helm-values/tempo-values.yaml \
  --create-namespace
```

## Validation
```bash
kubectl get pods -n monitoring
kubectl logs -n monitoring deployment/tempo
```

## Rollback
```bash
helm rollback tempo <revision> -n monitoring
```

## Notes
* Trace retention should be lower than metrics/logs
* Persistent storage or object storage required

# Alloy – Kubernetes Observability Agent

## Purpose
Alloy is a unified observability agent that collects **metrics, logs, and traces**
from Kubernetes workloads and forwards them to Prometheus, Loki, and Tempo.

Chart version used in UAT:

* Chart: alloy
* Version: 1.5.1
* App version: v1.12.1
* Namespace: monitoring
* Release: alloy

## Install Commands
```bash
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

helm upgrade --install alloy grafana/alloy \
  --version 1.5.1 \
  -n monitoring \
  -f monitoring-helm-values/alloy-values.yaml \
  --create-namespace
```

## Validation
```bash
kubectl get pods -n monitoring
kubectl logs -n monitoring daemonset/alloy
```

## Rollback
```bash
helm rollback alloy <revision> -n monitoring
```

## Notes
* Prometheus, Loki, and Tempo must be installed before Alloy

# MetalLB Setup – UAT Kubernetes (Internet Available)

## Overview

MetalLB provides a LoadBalancer implementation for on‑prem / bare‑metal Kubernetes clusters.
Since cloud load balancers (AWS ELB, Azure LB, etc.) are not available, MetalLB allows Service objects of type LoadBalancer to get external IP addresses from the local network.
This document describes MetalLB installation and configuration for UAT when internet access is available.

* MetalLB ModeLayer‑2 (ARP)

## Prerequisites

* Kubernetes cluster is healthy
* kubectl configured (kubectl get nodes works)
* Internet access from cluster nodes
* Unused IP range available in the same subnet as nodes

## MetalLB Architecture

* Controller: Manages IP allocation
* Speaker: Runs on each node and advertises IPs using ARP (Layer‑2)
* Mode: Layer‑2 (no BGP, no router config)

### Step 1: Install MetalLB
Apply the official MetalLB native (CRD‑based) manifest:
```bash
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/v0.13.12/config/manifests/metallb-native.yaml
```

### Verify installation
```bash
kubectl get pods -n metallb-system

Also confirm CRDs:
kubectl get crds | grep metallb
```

### Step 2: Define IP Address Pool and Configure Layer‑2 Advertisement

* MetalLB assigns external IPs from a predefined range.
* IPs must be unused
* Must be in the same Layer‑2 network as cluster nodes
* Must NOT overlap DHCP or node IPs
* UAT used IP range: 172.18.250.180 – 172.18.250.180

```bash
cd DevOps-Flow/k8s_deployments/AADP-MICRO-APPS/uat/metallb
apply both the files to Define IP Address Pool and Configure Layer‑2 Advertisement
```

### Step 3: Verify MetalLB Configuration
```bash
kubectl get ipaddresspool -n metallb-system
kubectl get l2advertisement -n metallb-system
```

# Envoy Gateway

## Purpose
Envoy Gateway provides **Ingress and Gateway API** support for Kubernetes,
handling north-south traffic routing into the cluster.

Chart version used in UAT:

* Chart: gateway-helm
* Version: v1.6.1
* App version: v1.6.1
* Namespace: envoy-gateway-system
* Release: eg

## Install Commands
```bash
helm repo add envoyproxy https://charts.envoyproxy.io
helm repo update

helm install eg envoyproxy/gateway-helm \
  --version v1.6.1 \
  -n envoy-gateway-system \
  --create-namespace
```

## Gateway Configuration
Use the following path for HTTPRoute and Gateway definitions:
* DevOps-Flow/k8s_deployments/envoy_gateway

## Key Features
* Kubernetes Gateway API support
* Envoy-based ingress controller
* High performance L7 routing
* Integrates with observability stack

## Validation
```bash
kubectl get pods -n envoy-gateway-system
kubectl get gateways -A
kubectl get gatewayclasses
kubectl get httproutes -A
```

## Rollback
```bash
helm rollback eg <revision> -n envoy-gateway-system
```

## Notes
* Requires Kubernetes Gateway API CRDs

### Post‑Install Health Checks | Final Validation:
```bash
helm ls -A
helm list -n monitoring
helm history prometheus -n monitoring

kubectl get pods -n monitoring
kubectl get pods -n envoy-gateway-system
kubectl get gateways -A
kubectl get gatewayclasses
kubectl get httproutes -A
```
![UAT-k8s-Cluster-monitoring-verification](Images/UAT-k8s-Cluster-monitoring-verification.png)
![envoy-gateway-grafana-verification](Images/envoy-gateway-grafana-verification.png)
